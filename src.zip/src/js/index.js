import '../scss/style.scss'

console.log('Works!')
